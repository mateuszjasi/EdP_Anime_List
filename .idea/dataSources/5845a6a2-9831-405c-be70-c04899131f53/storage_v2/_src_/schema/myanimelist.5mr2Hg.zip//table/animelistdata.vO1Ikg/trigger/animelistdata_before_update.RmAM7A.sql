create definer = root@localhost trigger animelistdata_BEFORE_UPDATE
    before update
    on animelistdata
    for each row
BEGIN
    IF NEW.progress != OLD.progress AND NEW.progress = NEW.progress_max THEN
		SET NEW.status = 'completed', NEW.finished = CURRENT_TIMESTAMP;
	END IF;
    IF NEW.progress != OLD.progress AND NEW.progress < NEW.progress_max THEN
		SET NEW.status = 'watching';
	END IF;
END;

