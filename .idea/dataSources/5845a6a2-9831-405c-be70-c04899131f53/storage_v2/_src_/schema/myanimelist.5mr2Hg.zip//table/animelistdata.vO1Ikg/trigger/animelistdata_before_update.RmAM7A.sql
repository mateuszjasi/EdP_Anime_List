create definer = root@localhost trigger animelistdata_BEFORE_UPDATE
    before update
    on animelistdata
    for each row
BEGIN
    IF NEW.progress = NEW.progress_max AND OLD.finished IS NULL THEN
		SET NEW.state = 1, NEW.finished = CURRENT_TIMESTAMP;
	END IF;
    IF NEW.progress < NEW.progress_max AND OLD.finished IS NOT NULL THEN
		SET NEW.finished = NULL;
	END IF;
END;

